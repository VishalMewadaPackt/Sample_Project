//
//  AppDelegate.swift
//  GuessTheNumber
//
//  Created by Giordano Scalzo on 23/08/2015.
//  Copyright © 2015 Effective Code Ltd. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        return true
    }
}

